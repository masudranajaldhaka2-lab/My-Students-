# My Students V1.0 — Full Source Project

Native Android/Kotlin/Jetpack Compose, offline-first single-tutor app.

## Included
- Dashboard
- Student add/search/deactivate
- Subject list + custom subject
- Custom study statuses
- Daily study record with assigned work/homework and parent note
- Daily attendance: Present / Absent / Late / Leave
- SQLite persistence and uniqueness protection for daily records
- Exam/ExamResult/Fee database schema ready for the next UI pass
- Professional PDF report generation + Android Sharesheet
- Settings foundation

## Build
Open `MyStudentsV1` in Android Studio, sync Gradle, then Run or Build APK.

This environment does not contain an Android SDK/Gradle installation, so an APK was not compiled here. The source is therefore provided as a buildable Android Studio project rather than claiming a tested APK.

## Release hardening still required
Before distributing V1.0, run a real Android Studio/device build and complete/verify PIN/biometric lock, full backup+restore, exam and fee entry screens, report editor, photo picker, recycle-bin UI, and automated tests.
